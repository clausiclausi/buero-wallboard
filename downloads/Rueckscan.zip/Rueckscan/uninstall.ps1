﻿# Rückscan entfernen. Fragt vorher, ob die gespeicherten Vorgänge mit gelöscht werden sollen.
$target = Join-Path $env:LOCALAPPDATA 'Rueckscan'
foreach ($dir in @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('Programs'))) {
  Remove-Item (Join-Path $dir 'Rückscan.lnk') -ErrorAction SilentlyContinue
}
Write-Host 'Verknüpfungen entfernt.'
$a = Read-Host 'Sollen auch alle gespeicherten Vorgänge gelöscht werden? (j/n)'
if ($a -eq 'j') {
  Remove-Item $target -Recurse -Force -ErrorAction SilentlyContinue
  Write-Host 'Programm und Daten gelöscht.'
} else {
  Remove-Item (Join-Path $target 'Rueckscan.html') -ErrorAction SilentlyContinue
  Write-Host 'Programm entfernt, Daten bleiben erhalten.'
}

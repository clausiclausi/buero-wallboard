﻿# Rückscan installieren: kopiert das Programm in den Benutzerordner und legt Verknüpfungen an. Keine Admin-Rechte nötig.
$ErrorActionPreference = 'Stop'
$src = Split-Path -Parent $MyInvocation.MyCommand.Path
$target = Join-Path $env:LOCALAPPDATA 'Rueckscan'
$profileDir = Join-Path $target 'edge-profil'
Write-Host ''
Write-Host 'Rückscan wird installiert ...'
New-Item -ItemType Directory -Force -Path $target | Out-Null
Copy-Item (Join-Path $src 'Rueckscan.html') $target -Force
Copy-Item (Join-Path $src 'Rueckscan.ico') $target -Force
Copy-Item (Join-Path $src 'LIESMICH.txt') $target -Force

$html = Join-Path $target 'Rueckscan.html'
$url = ([Uri]$html).AbsoluteUri
$edge = @((Join-Path ([Environment]::GetFolderPath('ProgramFilesX86')) 'Microsoft\Edge\Application\msedge.exe'), (Join-Path $env:ProgramFiles 'Microsoft\Edge\Application\msedge.exe')) | Where-Object { Test-Path $_ } | Select-Object -First 1

$shell = New-Object -ComObject WScript.Shell
$places = @([Environment]::GetFolderPath('Desktop'), (Join-Path ([Environment]::GetFolderPath('Programs')) ''))
foreach ($dir in $places) {
  $lnk = $shell.CreateShortcut((Join-Path $dir 'Rückscan.lnk'))
  if ($edge) {
    $lnk.TargetPath = $edge
    $lnk.Arguments = "--app=`"$url`" --user-data-dir=`"$profileDir`" --no-first-run --no-default-browser-check --disable-features=Translate --autoplay-policy=no-user-gesture-required --start-maximized"
  } else {
    $lnk.TargetPath = $html
  }
  $lnk.WorkingDirectory = $target
  $lnk.IconLocation = (Join-Path $target 'Rueckscan.ico')
  $lnk.Description = 'Rückscan: Geräte zurückscannen'
  $lnk.Save()
}
Write-Host ''
Write-Host 'Fertig. Auf dem Desktop liegt jetzt "Rückscan".'
Write-Host 'Deine Vorgänge bleiben bei einem Update erhalten.'
Write-Host ''
